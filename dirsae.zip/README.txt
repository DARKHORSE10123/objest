Overleaf upload
===============
1. New Project -> Upload Project -> select this zip
   (or extract and upload the folder contents)
2. Set main document to: pid_digitization_vision.tex
3. Compiler: pdfLaTeX (default)
4. Click Recompile

Required packages (TeX Live / Overleaf default): beamer, tikz, adjustbox,
booktabs, tabularx, graphicx, hyperref, xcolor, multirow, array, microtype.
